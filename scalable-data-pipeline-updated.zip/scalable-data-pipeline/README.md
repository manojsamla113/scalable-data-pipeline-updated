# Scalable Data Pipeline

A runnable Python project demonstrating chunked CSV and JSON Lines ingestion, data-quality validation, customer reference checks, duplicate detection, SQLite publishing, rejected-record quarantine, reconciliation metrics, and basic performance benchmarking.

## Requirements

- Python 3.10+
- Windows, macOS, or Linux

## Setup in VS Code

Open the project folder in VS Code. In the integrated terminal, run:

### Windows PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

If PowerShell blocks activation, run `python -m pip install -r requirements.txt` using the same Python interpreter selected in VS Code.

## Run CSV example

```powershell
python -m src.pipeline --input data/input/transactions.csv --format csv --chunk-size 3
```

## Run JSONL example

```powershell
python -m src.pipeline --input data/input/transactions.jsonl --format jsonl --chunk-size 2
```

## Generate a larger CSV

```powershell
python -m src.generator --rows 100000 --output data/input/transactions.csv
```

The generator uses customer IDs C0001–C1000. Before running generated data, regenerate the customer reference file with IDs C0001–C1000, for example:

```powershell
@("customer_id") + (1..1000 | ForEach-Object { "C{0:D4}" -f $_ }) | Set-Content -Encoding utf8 data/input/customers.csv
```

## Run tests

```powershell
python -m pytest -v
```

## Benchmark

```powershell
python -m src.benchmark --rows 100000 --chunk-sizes 1000 5000 10000
```

Benchmark outputs:
- `reports/benchmark_results.json`
- `reports/benchmark_results.csv`

## Outputs

- `data/output/transactions.db`: SQLite target and run metadata
- `data/rejects/rejected_records.csv`: invalid and malformed records
- `reports/reconciliation.json`: run metrics and reconciliation result

## Validation rules

- Required fields: transaction_id, customer_id, amount, status, event_timestamp
- Amount must be numeric and greater than zero
- Status must be SUCCESS, PENDING, or FAILED
- Timestamp must parse as a date/time
- Customer ID must exist in `customers.csv`
- Duplicate transaction IDs in the same input run are rejected
- The target database's primary key prevents inserting an existing transaction ID twice

## Memory behavior and limitations

- CSV input is read with pandas `chunksize`; JSONL is read line by line.
- Duplicate IDs for the current run are tracked in SQLite, not a Python set.
- Current-chunk DataFrames still use memory proportional to chunk size.
- Malformed JSONL lines are quarantined individually.
- Malformed CSV parsing errors currently fail the run rather than being quarantined individually.
- SQLite writes commit by chunk. If a later chunk fails, previously committed chunks remain in the target.
- Benchmark RSS values are sampled and are approximate, not a formal peak-memory guarantee.
- Reconciliation is input_records = accepted_records + rejected_records. `published_records` counts new database inserts and can be lower on reruns.
